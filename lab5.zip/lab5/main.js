function load() {
  const column_1 = [7, 5, 3, 8, 5, 7, 4, 10, 8, 1, 7, 2, 2, 10, 4, 6, 8, 1, 9, 7, 9, 1, 1, 1, 1, 10, 6, 5, 2, 10];  
  const column_2 = [6, 6, 8, 8, 7, 4, 8, 8, 10, 9, 4, 9, 9, 7, 3, 5, 3, 5, 4, 1, 8, 8, 7, 4, 1, 10, 10, 2, 9, 7];
  const column_3 = [58, 87, 86, 70, 55, 80, 59, 86, 41, 82, 43, 72, 98, 86, 70, 65, 88, 56, 66, 90, 65, 77, 48, 52, 63, 67, 63, 66, 97, 71]; 
  const column_4 = [55, 78, 44, 66, 79, 55, 94, 77, 93, 50, 82, 78, 90, 76, 75, 84, 75, 53, 44, 99, 88, 78, 88, 94, 79, 54, 76, 49, 95, 94];

  let sumTotal = 0;

  for (let i = 0; i < column_1.length; i++) {
    sumTotal += column_1[i] + column_2[i] + column_3[i] + column_4[i];
  }
  

  console.log("Sum = " + sumTotal);

  const result = {
    sumTotal: sumTotal,
    column_1: column_1,
    column_2: column_2,
    column_3: column_3,
    column_4: column_4
  };

  console.log(result);
}